# Baseline

请将正式批准的 PRD 放置为：

`docs/baseline/prd-v1.4.md`

在 PRD 正式批准前，不建议让 Codex 把候选版本当作不可变开发承诺。

本目录建议同时维护：

- `prd-v1.4.md`
- `requirement-baseline.yaml`
- `baseline-signoff.md`
- `change-log.md`
